export type OptionsType = {
    groupBy: string,
    title: string
}
