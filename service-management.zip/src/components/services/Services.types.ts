export type OptionsType = {
    groupBy: string,
    title: string
}

export type PropsType = {
    value: any,
    handleChange: (value: any) => void
}