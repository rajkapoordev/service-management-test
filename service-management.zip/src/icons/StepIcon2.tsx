import DollarIcon from '../assets/DollarIcon.png'

const StepIcon2 = () => <img src={DollarIcon} />


export default StepIcon2
