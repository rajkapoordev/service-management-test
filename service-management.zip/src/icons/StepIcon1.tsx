
import clockIcon from '../assets/ClockIcon.png'

const StepIcon1 = () => <img src={clockIcon} />

export default StepIcon1
