import MoneyIcon from '../assets/MoneyIcon.png'

const StepIcon3 = () => <img src={MoneyIcon} />
export default StepIcon3
