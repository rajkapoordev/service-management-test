export type StateType = {
    selectedItem: string,
    searchText: string,
}